prompt --application/pages/page_00065
begin
--   Manifest
--     PAGE: 00065
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>17663301221950901
,p_default_application_id=>133
,p_default_id_offset=>0
,p_default_owner=>'NOONA_APP'
);
wwv_flow_imp_page.create_page(
 p_id=>65
,p_name=>'Restaurant Setup'
,p_alias=>'RESTAURANT-SETUP'
,p_step_title=>'إعداد المطعم والقائمة'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(91820269000000224)
,p_protection_level=>'C'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000285)
,p_plug_name=>'صالة جديدة'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000286)
,p_name=>'P65_A_CODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91820269000000285)
,p_prompt=>'الرمز'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>10
,p_cMaxlength=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000287)
,p_name=>'P65_A_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91820269000000285)
,p_prompt=>'اسم الصالة (داخلية، خارجية، عائلات، VIP...)'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000288)
,p_name=>'P65_A_TERM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(91820269000000285)
,p_prompt=>'نقطة البيع'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select code || '' - '' || name_ar d, id r from pos_terminal where company_id = noona_rst_pkg.company and status_code = ''ACTIVE'' order by code'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000289)
,p_name=>'P65_A_SORT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(91820269000000285)
,p_prompt=>'الترتيب'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>20
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91820269000000290)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(91820269000000285)
,p_button_name=>'ADD_AREA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'إضافة الصالة'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000291)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Area'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l number;',
'begin',
'    l := noona_rst_pkg.save_area(null, :P65_A_CODE, :P65_A_NAME, :P65_A_TERM, to_number(:P65_A_SORT));',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91820269000000290)
,p_process_success_message=>'تمت إضافة الصالة'
,p_internal_uid=>91820269000000291
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000292)
,p_plug_name=>'إضافة طاولات'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000293)
,p_name=>'P65_T_AREA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91820269000000292)
,p_prompt=>'الصالة'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name_ar || '' ('' || code || '')'' d, id r from rst_area where company_id = noona_rst_pkg.company order by sort_order, code'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000294)
,p_name=>'P65_T_COUNT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91820269000000292)
,p_prompt=>'عدد الطاولات'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>20
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000295)
,p_name=>'P65_T_PREFIX'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(91820269000000292)
,p_prompt=>'بادئة الرقم'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>6
,p_cMaxlength=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000296)
,p_name=>'P65_T_SEATS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(91820269000000292)
,p_prompt=>'المقاعد لكل طاولة'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>20
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91820269000000297)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(91820269000000292)
,p_button_name=>'ADD_TABLES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'إضافة الطاولات'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000298)
,p_process_sequence=>5
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Defaults'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P65_T_PREFIX := nvl(:P65_T_PREFIX, ''T'');',
':P65_T_SEATS := nvl(:P65_T_SEATS, 4);',
':P65_T_COUNT := nvl(:P65_T_COUNT, 5);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>91820269000000298
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000299)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Tables'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l number;',
'begin',
'    l := noona_rst_pkg.add_tables(:P65_T_AREA, to_number(:P65_T_COUNT), :P65_T_PREFIX, to_number(:P65_T_SEATS));',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91820269000000297)
,p_process_success_message=>'تمت إضافة الطاولات'
,p_internal_uid=>91820269000000299
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000300)
,p_plug_name=>'تعديل طاولة'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>25
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000301)
,p_name=>'P65_E_TABLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91820269000000300)
,p_prompt=>'الطاولة'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select a.name_ar || '' - '' || t.code d, t.id r from rst_table t join rst_area a on a.id = t.area_id where t.company_id = noona_rst_pkg.company order by a.sort_order, t.sort_order, t.code'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- اختر -'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000302)
,p_name=>'P65_E_SEATS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91820269000000300)
,p_prompt=>'المقاعد'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>20
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000303)
,p_name=>'P65_E_SHAPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(91820269000000300)
,p_prompt=>'الشكل'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:مربعة;SQUARE,دائرية;ROUND,طويلة;LONG,ركن;BOOTH'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- بلا تغيير -'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000304)
,p_name=>'P65_E_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(91820269000000300)
,p_prompt=>'الحالة'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:نشط;ACTIVE,موقوف;INACTIVE'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- بلا تغيير -'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91820269000000305)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(91820269000000300)
,p_button_name=>'SAVE_TABLE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'حفظ الطاولة'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000306)
,p_process_sequence=>25
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Edit Table'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l number; l_area number; l_code varchar2(30);',
'begin',
'    select area_id, code into l_area, l_code from rst_table where id = :P65_E_TABLE and company_id = noona_rst_pkg.company;',
'    l := noona_rst_pkg.save_table(:P65_E_TABLE, l_area, l_code, null, to_number(:P65_E_SEATS), :P65_E_SHAPE, :P65_E_STATUS);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91820269000000305)
,p_process_success_message=>'تم حفظ الطاولة'
,p_internal_uid=>91820269000000306
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000307)
,p_plug_name=>'صنف في قائمة الطعام'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000308)
,p_name=>'P65_M_ITEM'
,p_item_sequence=>5
,p_item_plug_id=>wwv_flow_imp.id(91820269000000307)
,p_prompt=>'تعديل صنف قائم'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select i.name_ar d, i.id r from inv_item i where i.category_id in (select id from inv_item_category where code = ''MENU'' or parent_category_id = (select min(id) from inv_item_category where code = ''MENU'')) order by i.name_ar'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- صنف جديد -'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000309)
,p_process_sequence=>6
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :P65_M_ITEM is not null then',
'        select i.name_ar, i.category_id, c.sale_price, case i.status_code when ''ACTIVE'' then ''ACTIVE'' else ''INACTIVE'' end,',
'               case when i.item_type in (''NON_STOCK'', ''SERVICE'') then ''RECIPE'' else ''STOCK'' end',
'          into :P65_M_NAME, :P65_M_CAT, :P65_M_PRICE, :P65_M_STATUS, :P65_M_STOCK',
'          from inv_item i left join inv_item_company c on c.item_id = i.id and c.company_id = noona_rst_pkg.company where i.id = :P65_M_ITEM;',
'    end if;',
'exception when no_data_found then null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>91820269000000309
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000310)
,p_name=>'P65_M_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91820269000000307)
,p_prompt=>'اسم الصنف'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000311)
,p_name=>'P65_M_CAT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91820269000000307)
,p_prompt=>'فئة القائمة'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name_ar d, id r from inv_item_category where code = ''MENU'' or parent_category_id = (select min(id) from inv_item_category where code = ''MENU'') order by case when code = ''MENU'' then 0 else 1 end, name_ar'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000312)
,p_name=>'P65_M_PRICE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(91820269000000307)
,p_prompt=>'السعر شامل الضريبة'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>20
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000313)
,p_name=>'P65_M_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(91820269000000307)
,p_prompt=>'الحالة'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:نشط;ACTIVE,موقوف;INACTIVE'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000314)
,p_name=>'P65_M_STOCK'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(91820269000000307)
,p_prompt=>'الخصم من المخزون'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:وجبة/مشروب محضر يصرف مكونات وصفته;RECIPE,صنف مخزني يباع كما هو (علبة، مياه);STOCK'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91820269000000315)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(91820269000000307)
,p_button_name=>'SAVE_ITEM'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'حفظ الصنف'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000316)
,p_plug_name=>'فئة جديدة في القائمة'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>35
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000317)
,p_name=>'P65_C_CODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91820269000000316)
,p_prompt=>'الرمز'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>12
,p_cMaxlength=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000318)
,p_name=>'P65_C_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91820269000000316)
,p_prompt=>'اسم الفئة (مشروبات ساخنة، وجبات، حلويات...)'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91820269000000319)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(91820269000000316)
,p_button_name=>'ADD_CAT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'إضافة الفئة'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000320)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l number;',
'begin',
'    l := noona_rst_pkg.save_menu_item(to_number(:P65_M_ITEM), :P65_M_NAME, to_number(:P65_M_CAT), to_number(:P65_M_PRICE), :P65_M_STATUS,',
'                                      :P65_M_STOCK);',
'    if :P65_M_STOCK = ''RECIPE'' then :P65_R_ITEM := l; end if;   -- انتقل لتعريف وصفته',
'    :P65_M_ITEM := null; :P65_M_NAME := null; :P65_M_PRICE := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91820269000000315)
,p_process_success_message=>'تم حفظ صنف القائمة'
,p_internal_uid=>91820269000000320
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000321)
,p_process_sequence=>35
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Category'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l number;',
'begin',
'    l := noona_rst_pkg.menu_category(:P65_C_CODE, :P65_C_NAME);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91820269000000319)
,p_process_success_message=>'تمت إضافة الفئة'
,p_internal_uid=>91820269000000321
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000322)
,p_plug_name=>'الوصفة (مكونات الصنف المصروفة من المخزون)'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>36
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000323)
,p_name=>'P65_R_ITEM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91820269000000322)
,p_prompt=>'صنف القائمة'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select i.name_ar d, i.id r from inv_item i where i.item_type in (''NON_STOCK'', ''SERVICE'') and i.category_id in (select id from inv_item_category where code = ''MENU'' or parent_category_id = (select min(id) from inv_item_category where code = ''MENU'')) order by i.name_ar'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- اختر الوجبة -'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000324)
,p_name=>'P65_R_COMP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91820269000000322)
,p_prompt=>'المكون (مادة خام أو صنف مخزني)'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select i.name_ar || '' ('' || u.name_ar || '')'' d, i.id r from inv_item i join inv_uom u on u.id = i.base_uom_id where i.item_type not in (''SERVICE'', ''NON_STOCK'') and i.status_code = ''ACTIVE'' order by case when i.category_id = (select min(id) from inv_item_category where code = ''RST_ING'') then 0 else 1 end, i.name_ar'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- اختر المكون -'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000325)
,p_name=>'P65_R_QTY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(91820269000000322)
,p_prompt=>'الكمية لكل حصة (بوحدة المكون: 0.150 كجم مثلاً)'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>20
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91820269000000326)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(91820269000000322)
,p_button_name=>'SET_COMP'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'إضافة / تعديل المكون'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91820269000000327)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(91820269000000322)
,p_button_name=>'DEL_COMP'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'حذف المكون'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000328)
,p_plug_name=>'مكونات الوصفة وتكلفة الحصة'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>37
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P65_R_ITEM is not null'
,p_plug_display_when_cond2=>'PLSQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return noona_rst_pkg.recipe_html(:P65_R_ITEM);'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000329)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recipe Set'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'noona_rst_pkg.recipe_set(to_number(:P65_R_ITEM), to_number(:P65_R_COMP), to_number(:P65_R_QTY));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91820269000000326)
,p_process_success_message=>'تم حفظ المكون في الوصفة'
,p_internal_uid=>91820269000000329
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000330)
,p_process_sequence=>45
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recipe Remove'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'noona_rst_pkg.recipe_remove(to_number(:P65_R_ITEM), to_number(:P65_R_COMP));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91820269000000327)
,p_process_success_message=>'تم حذف المكون من الوصفة'
,p_internal_uid=>91820269000000330
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000331)
,p_plug_name=>'مادة خام جديدة للمطبخ'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>38
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000332)
,p_name=>'P65_G_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91820269000000331)
,p_prompt=>'اسم المادة (أرز بسمتي، صدر دجاج، حليب...)'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91820269000000333)
,p_name=>'P65_G_UOM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91820269000000331)
,p_prompt=>'وحدة القياس'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name_ar || '' ('' || code || '')'' d, id r from inv_uom where is_active = ''Y'' order by case code when ''KG'' then 0 when ''L'' then 1 when ''PCS'' then 2 else 3 end, name_ar'
,p_cHeight=>1
,p_lov_display_extra=>'NO'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91820269000000334)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(91820269000000331)
,p_button_name=>'ADD_ING'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'إضافة المادة'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000335)
,p_plug_name=>'ملاحظة المخزون'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>39
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="nn-hint">تدخل أرصدة المواد الخام بالمشتريات أو برصيد افتتاحي من تطبيق «سلسلة الإمداد والمخزون»، وتصرف تلقائياً من مستودع نقطة البيع عند سداد كل طلب، وتقيد تكلفتها عند إقفال الوردية.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91820269000000336)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ingredient'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare l number;',
'begin',
'    l := noona_rst_pkg.save_ingredient(:P65_G_NAME, to_number(:P65_G_UOM));',
'    :P65_R_COMP := l; :P65_G_NAME := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91820269000000334)
,p_process_success_message=>'تمت إضافة المادة الخام؛ اخترها مكوناً في الوصفة'
,p_internal_uid=>91820269000000336
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000337)
,p_plug_name=>'الصالات والطاولات'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.id, a.name_ar as area, t.code, t.name_ar, t.seats, case t.shape when ''ROUND'' then ''دائرية'' when ''LONG'' then ''طويلة''',
'       when ''BOOTH'' then ''ركن'' else ''مربعة'' end as shape, (select code from pos_terminal where id = a.terminal_id) as terminal,',
'       case t.status_code when ''ACTIVE'' then ''نشطة'' else ''موقوفة'' end as status',
'  from rst_table t join rst_area a on a.id = t.area_id where t.company_id = noona_rst_pkg.company order by a.sort_order, t.sort_order, t.code'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'الصالات والطاولات'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(91820269000000338)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'لا توجد بيانات'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'N'
,p_owner=>'NOONA'
,p_internal_uid=>91820269000000338
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000340)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'#'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000341)
,p_db_column_name=>'AREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'الصالة'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000342)
,p_db_column_name=>'CODE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'الرقم'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000343)
,p_db_column_name=>'NAME_AR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'الاسم'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000344)
,p_db_column_name=>'SEATS'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'المقاعد'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000345)
,p_db_column_name=>'SHAPE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'الشكل'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000346)
,p_db_column_name=>'TERMINAL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'نقطة البيع'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000347)
,p_db_column_name=>'STATUS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'الحالة'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(91820269000000339)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'339'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'AREA:CODE:NAME_AR:SEATS:SHAPE:TERMINAL:STATUS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000348)
,p_plug_name=>'قائمة الطعام'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.id, g.name_ar as cat, i.item_no, i.name_ar, c.sale_price, case c.prices_include_tax when ''Y'' then ''شامل'' else ''غير شامل'' end as incl,',
'       case when i.item_type not in (''NON_STOCK'', ''SERVICE'') then ''صنف مخزني'' when noona_rst_pkg.recipe_cost(i.id) is not null then ''وصفة''',
'            else ''بلا خصم (لا وصفة)'' end as stock_mode,',
'       case when i.item_type in (''NON_STOCK'', ''SERVICE'') then noona_rst_pkg.recipe_cost(i.id) else noona_inv_pkg.avg_cost(i.id) end as unit_cost,',
'       round(100 * case when i.item_type in (''NON_STOCK'', ''SERVICE'') then noona_rst_pkg.recipe_cost(i.id) else noona_inv_pkg.avg_cost(i.id) end',
'             / nullif(c.sale_price / 1.15, 0), 1) as cost_pct,',
'       case i.status_code when ''ACTIVE'' then ''نشط'' else ''موقوف'' end as status',
'  from inv_item i join inv_item_category g on g.id = i.category_id',
'  left join inv_item_company c on c.item_id = i.id and c.company_id = noona_rst_pkg.company',
' where g.code = ''MENU'' or g.parent_category_id = (select min(id) from inv_item_category where code = ''MENU'') order by g.name_ar, i.name_ar'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'قائمة الطعام'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(91820269000000349)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'لا توجد بيانات'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'N'
,p_owner=>'NOONA'
,p_internal_uid=>91820269000000349
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000351)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'#'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000352)
,p_db_column_name=>'CAT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'الفئة'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000353)
,p_db_column_name=>'ITEM_NO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'رقم الصنف'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000354)
,p_db_column_name=>'NAME_AR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'الصنف'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000355)
,p_db_column_name=>'SALE_PRICE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'السعر'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000356)
,p_db_column_name=>'INCL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'الضريبة'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000357)
,p_db_column_name=>'STOCK_MODE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'الخصم من المخزون'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000358)
,p_db_column_name=>'UNIT_COST'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'تكلفة الحصة'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000359)
,p_db_column_name=>'COST_PCT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'نسبة التكلفة %'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91820269000000360)
,p_db_column_name=>'STATUS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'الحالة'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(91820269000000350)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'350'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CAT:ITEM_NO:NAME_AR:SALE_PRICE:INCL:STOCK_MODE:UNIT_COST:COST_PCT:STATUS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91820269000000361)
,p_plug_name=>'ملاحظة'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="nn-hint">الوجبات والمشروبات المحضرة تصرف مكونات وصفتها من المخزون عند السداد؛ والأصناف المخزنية (علب المشروبات والمياه) تصرف بنفسها. الصنف المحضر بلا وصفة لا يصرف شيئاً.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(91820269000000362)
,p_branch_action=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);

wwv_flow_imp.component_end;
end;
/
