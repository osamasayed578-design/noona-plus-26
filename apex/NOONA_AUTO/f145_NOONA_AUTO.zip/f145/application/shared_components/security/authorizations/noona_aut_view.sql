prompt --application/shared_components/security/authorizations/noona_aut_view
begin
--   Manifest
--     SECURITY SCHEME: NOONA - Auto Service
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>17663301221950901
,p_default_application_id=>145
,p_default_id_offset=>0
,p_default_owner=>'NOONA_APP'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(91820280000000009)
,p_name=>'NOONA - Auto Service'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>'return noona_security_pkg.has_permission(''AUT_JOB_CARD.VIEW'', noona_aut_pkg.company) = ''Y'';'
,p_error_message=>'شاشات مركز الخدمة تتطلب صلاحية عرض أوامر الإصلاح / Auto service access required'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
